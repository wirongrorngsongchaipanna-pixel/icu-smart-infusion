ICU Smart Infusion App v1.0 — คู่มือใช้งานและติดตั้ง
====================================================

ไฟล์สำคัญ
- index.html              ตัวแอป
- manifest.webmanifest    ข้อมูล PWA / ไอคอน / ชื่อแอป
- sw.js                   Service Worker สำหรับ Offline
- icons/                  ไอคอน 192 และ 512 px

สำคัญ: PWA ต้องเปิดผ่าน HTTPS (หรือ localhost ตอนทดสอบ)
การดับเบิลคลิก index.html จากไฟล์ในโทรศัพท์/คอมพิวเตอร์จะเปิดหน้าเว็บได้ แต่จะไม่สามารถติดตั้ง PWA และ Service Worker ได้อย่างสมบูรณ์

วิธีทดสอบบน Windows
1) แตก ZIP
2) เปิด Command Prompt ในโฟลเดอร์แอป
3) ถ้ามี Python ให้รัน: python -m http.server 8080
4) เปิด http://localhost:8080 ใน Chrome/Edge

วิธีนำขึ้นใช้งานจริง
- อัปโหลดทั้งโฟลเดอร์ไปยัง Web server ที่เป็น HTTPS
- หรือใช้บริการ static hosting เช่น GitHub Pages / Cloudflare Pages / Netlify / Firebase Hosting
- ห้ามเปลี่ยนชื่อหรือตำแหน่ง sw.js, manifest.webmanifest และโฟลเดอร์ icons โดยไม่แก้ path ใน index.html

ติดตั้งบน iPhone / iPad
1) เปิด URL ของแอปด้วย Safari
2) แตะปุ่ม Share
3) เลือก Add to Home Screen
4) ยืนยันชื่อ ICU Infusion แล้วแตะ Add
5) เปิดแอปจากไอคอนบน Home Screen อย่างน้อย 1 ครั้งขณะออนไลน์ เพื่อให้ไฟล์ Offline ถูก cache

ติดตั้งบน Android
1) เปิด URL ของแอปด้วย Chrome
2) แตะเมนู ⋮
3) เลือก Install app หรือ Add to Home screen
4) ยืนยันการติดตั้ง
5) เปิดแอปอย่างน้อย 1 ครั้งขณะออนไลน์ เพื่อให้ไฟล์ Offline ถูก cache

การแก้ไข logic ใน v1.0
- Dose → Rate รองรับหน่วย /min และ /hr ตามหน่วยที่เลือก
- Rate → Dose คืนค่าเป็นหน่วยมาตรฐานของยาจริง เช่น mcg/kg/hr จะไม่ถูกบังคับเป็น mcg/kg/min
- Custom ใน Rate → Dose สามารถเลือกหน่วย Dose ได้เอง
- หน่วยความเข้มข้นแบบ Units ถูกแยกจาก mcg/mg เพื่อป้องกันการแปลง mass ↔ Units ที่ไม่ถูกต้อง
- Input ที่เป็นศูนย์/ค่าติดลบจะไม่ถูกนำไปคำนวณ
- ตัด dependency Google Fonts เพื่อให้ใช้งาน Offline ได้สมบูรณ์ขึ้น
- ปรับ Mobile UI, safe-area, sticky tabs และขนาด input สำหรับ touch

ข้อควรระวังด้านคลินิก
แอปนี้เป็นเครื่องมือช่วยคำนวณ ไม่ใช่อุปกรณ์ทางการแพทย์ และไม่ทดแทนคำสั่งแพทย์/นโยบายยา/Independent Double Check ของหน่วยงาน
ก่อนใช้จริงควรทำ clinical validation โดยเภสัชกรและทีม ICU กับ concentration มาตรฐานและ dose range ของหน่วยงาน

เวอร์ชัน: 1.0.0
